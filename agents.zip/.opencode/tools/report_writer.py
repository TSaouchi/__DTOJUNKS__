#!/usr/bin/env python3
"""Write a list of row objects out to a CSV file at a given path.

Standalone CLI, independent of OpenCode:

    python3 report_writer.py --output-path ./out/report.csv \
        --rows '[{"level": "ERROR", "message": "boom"}]' --columns __NONE__

Prints a single JSON object to stdout on success:

    {"path": "./out/report.csv", "rows_written": 1, "columns": ["level", "message"]}

On failure, prints {"error": "..."} to stderr and exits with status 1.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

NONE_SENTINEL = "__NONE__"


def resolve(value: str | None) -> str | None:
    """Convert the '__NONE__' sentinel (used by the .ts wrapper) back to None."""
    return None if value in (None, NONE_SENTINEL) else value


def determine_columns(rows: list[dict], explicit: list[str] | None) -> list[str]:
    if explicit:
        return explicit
    columns: list[str] = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                columns.append(key)
    return columns


def write_csv(output_path: Path, rows: list[dict], columns: list[str]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> int:
    parser = argparse.ArgumentParser(description="Write rows out to a CSV report.")
    parser.add_argument("--output-path", required=True, help="Destination path for the CSV file.")
    parser.add_argument("--rows", required=True, help="JSON array of row objects, e.g. '[{\"a\": 1}]'.")
    parser.add_argument("--columns", default=NONE_SENTINEL, help="JSON array of explicit column names/order.")
    args = parser.parse_args()

    try:
        rows = json.loads(args.rows)
        if not isinstance(rows, list):
            raise ValueError("--rows must be a JSON array of objects")
    except (json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"error": f"invalid --rows: {exc}"}), file=sys.stderr)
        return 1

    columns_raw = resolve(args.columns)
    explicit_columns: list[str] | None = None
    if columns_raw is not None:
        try:
            explicit_columns = json.loads(columns_raw)
        except json.JSONDecodeError as exc:
            print(json.dumps({"error": f"invalid --columns: {exc}"}), file=sys.stderr)
            return 1

    columns = determine_columns(rows, explicit_columns)
    output_path = Path(args.output_path)

    try:
        write_csv(output_path, rows, columns)
    except OSError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1

    print(json.dumps({"path": str(output_path), "rows_written": len(rows), "columns": columns}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
