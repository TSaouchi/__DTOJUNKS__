import { tool } from "@opencode-ai/plugin"
import path from "path"

const NONE = "__NONE__"

export default tool({
  description: "Write a list of row objects out to a CSV file at a given path, creating parent directories as needed.",
  args: {
    output_path: tool.schema.string().describe("Destination path for the CSV file."),
    rows: tool.schema
      .array(tool.schema.record(tool.schema.any()))
      .describe('Row objects to write, e.g. [{"timestamp": "...", "level": "ERROR", "message": "..."}].'),
    columns: tool.schema
      .array(tool.schema.string())
      .optional()
      .describe("Explicit column order/subset. Defaults to the union of all keys found across rows."),
  },
  async execute(args, context) {
    const script = path.join(context.worktree, ".opencode/tools/report_writer.py")
    const rowsJson = JSON.stringify(args.rows)
    const columnsJson = args.columns ? JSON.stringify(args.columns) : NONE

    const result = await Bun.$`python3 ${script} --output-path ${args.output_path} --rows ${rowsJson} --columns ${columnsJson}`.text()
    return result.trim()
  },
})
