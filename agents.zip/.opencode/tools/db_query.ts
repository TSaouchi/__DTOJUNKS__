import { tool } from "@opencode-ai/plugin"
import path from "path"

const NONE = "__NONE__"

export default tool({
  description:
    "Execute a SQL statement against the project database and return the results as JSON. " +
    "Read-only by default (INSERT/UPDATE/DELETE/DDL are rejected unless allow_write is true).",
  args: {
    query: tool.schema.string().describe("SQL statement to execute. Use '?' placeholders for params."),
    params: tool.schema.array(tool.schema.any()).optional().describe("Positional parameters bound to '?' placeholders."),
    max_rows: tool.schema.number().optional().describe("Maximum rows to return for SELECT-like queries. Defaults to 200."),
    allow_write: tool.schema.boolean().optional().describe("Set true to permit INSERT/UPDATE/DELETE/DDL statements. Defaults to false."),
  },
  async execute(args, context) {
    const script = path.join(context.worktree, ".opencode/tools/db_query.py")
    const params = args.params ? JSON.stringify(args.params) : NONE
    const maxRows = args.max_rows !== undefined ? String(args.max_rows) : NONE
    const allowWrite = args.allow_write ? "true" : "false"

    const result = await Bun.$`python3 ${script} --query ${args.query} --params ${params} --max-rows ${maxRows} --allow-write ${allowWrite}`.text()
    return result.trim()
  },
})
