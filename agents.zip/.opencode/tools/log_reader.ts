import { tool } from "@opencode-ai/plugin"
import path from "path"

const NONE = "__NONE__"

export default tool({
  description:
    "Read and filter log entries from a file, or every file in a directory. " +
    "Supports filtering by regex pattern, log level substring, and tailing the last N matches.",
  args: {
    path: tool.schema.string().describe("Absolute or project-relative path to a log file or a directory of log files."),
    pattern: tool.schema.string().optional().describe("Regex pattern; only lines matching it are returned."),
    level: tool.schema.string().optional().describe("Log level substring to filter on, e.g. ERROR, WARN, INFO."),
    tail: tool.schema.number().optional().describe("Only return the last N matching entries."),
  },
  async execute(args, context) {
    const script = path.join(context.worktree, ".opencode/tools/log_reader.py")
    const pattern = args.pattern ?? NONE
    const level = args.level ?? NONE
    const tail = args.tail !== undefined ? String(args.tail) : NONE

    const result = await Bun.$`python3 ${script} --path ${args.path} --pattern ${pattern} --level ${level} --tail ${tail}`.text()
    return result.trim()
  },
})
