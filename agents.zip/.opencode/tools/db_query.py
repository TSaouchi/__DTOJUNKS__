#!/usr/bin/env python3
"""Execute one SQL statement and return the results as JSON.

Standalone CLI, independent of OpenCode:

    python3 db_query.py --query "SELECT name FROM sqlite_master" \
        --params __NONE__ --max-rows 200 --allow-write false

Prints a single JSON object to stdout on success:

    {"columns": ["name"], "rows": [{"name": "users"}], "row_count": 1, "truncated": false}

or, for a write statement:

    {"message": "statement executed", "rows_affected": 1}

On failure, prints {"error": "..."} to stderr and exits with status 1.

--- Swapping the backend ---
This scaffold ships with a zero-dependency SQLite backend so it runs out of the
box. To point it at Postgres or Oracle, only `get_connection()` below needs to
change:

    # Postgres (pip install psycopg2-binary):
    import psycopg2
    def get_connection():
        return psycopg2.connect(os.environ["AGENT_DB_URL"])

    # Oracle (pip install oracledb):
    import oracledb
    def get_connection():
        return oracledb.connect(os.environ["AGENT_DB_URL"])  # user/pass@dsn

Everything else — the read-only guard, row limiting, and JSON shaping — stays
the same as long as the driver follows the DB-API 2.0 cursor interface.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

NONE_SENTINEL = "__NONE__"
DEFAULT_MAX_ROWS = 200

# First keyword of a statement that mutates schema or data. PRAGMA is allowed
# through since it's routinely needed for read-only SQLite schema inspection
# (e.g. PRAGMA table_info(...)).
WRITE_KEYWORDS = {
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE",
    "CREATE", "REPLACE", "GRANT", "REVOKE", "ATTACH", "DETACH", "VACUUM",
}


def resolve(value: str | None) -> str | None:
    """Convert the '__NONE__' sentinel (used by the .ts wrapper) back to None."""
    return None if value in (None, NONE_SENTINEL) else value


def get_connection() -> sqlite3.Connection:
    """Zero-dependency default backend. See the module docstring to swap this
    for Postgres or Oracle without touching anything else in this file."""
    db_path = os.environ.get("AGENT_DB_PATH", "data/agent.db")
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(db_path)


def leading_keyword(query: str) -> str:
    stripped = query.strip().lstrip("(")
    match = re.match(r"[A-Za-z]+", stripped)
    return match.group(0).upper() if match else ""


def run_query(query: str, params: list, max_rows: int, allow_write: bool) -> dict:
    keyword = leading_keyword(query)
    if keyword in WRITE_KEYWORDS and not allow_write:
        raise PermissionError(
            f"'{keyword}' statements are blocked in read-only mode. "
            "Pass allow_write=true to permit this."
        )

    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(query, params)

        if cursor.description is None:
            conn.commit()
            return {"message": "statement executed", "rows_affected": cursor.rowcount}

        columns = [col[0] for col in cursor.description]
        fetched = cursor.fetchmany(max_rows + 1)
        truncated = len(fetched) > max_rows
        fetched = fetched[:max_rows]
        rows = [dict(zip(columns, row)) for row in fetched]
        return {"columns": columns, "rows": rows, "row_count": len(rows), "truncated": truncated}
    finally:
        conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute a SQL statement and return JSON results.")
    parser.add_argument("--query", required=True, help="SQL statement to execute.")
    parser.add_argument("--params", default=NONE_SENTINEL, help="JSON array of positional parameters for '?' placeholders.")
    parser.add_argument("--max-rows", default=NONE_SENTINEL, help="Maximum rows to return for SELECT-like queries.")
    parser.add_argument("--allow-write", default="false", help="'true' to permit INSERT/UPDATE/DELETE/DDL statements.")
    args = parser.parse_args()

    params_raw = resolve(args.params)
    try:
        params = json.loads(params_raw) if params_raw is not None else []
        if not isinstance(params, list):
            raise ValueError("--params must be a JSON array")
    except (json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"error": f"invalid --params: {exc}"}), file=sys.stderr)
        return 1

    max_rows_raw = resolve(args.max_rows)
    max_rows = int(max_rows_raw) if max_rows_raw is not None else DEFAULT_MAX_ROWS
    allow_write = args.allow_write.strip().lower() == "true"

    try:
        result = run_query(args.query, params, max_rows, allow_write)
    except PermissionError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1
    except sqlite3.Error as exc:
        print(json.dumps({"error": f"database error: {exc}"}), file=sys.stderr)
        return 1

    print(json.dumps(result, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
