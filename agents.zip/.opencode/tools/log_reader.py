#!/usr/bin/env python3
"""Read and filter log entries from a file or a directory of log files.

Standalone CLI, independent of OpenCode:

    python3 log_reader.py --path ./app.log --level ERROR --tail 50

Prints a single JSON object to stdout on success:

    {"count": 3, "entries": [{"file": "...", "line_number": 12, "line": "..."}]}

On failure, prints {"error": "..."} to stderr and exits with status 1.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

NONE_SENTINEL = "__NONE__"


def resolve(value: str | None) -> str | None:
    """Convert the '__NONE__' sentinel (used by the .ts wrapper) back to None."""
    return None if value in (None, NONE_SENTINEL) else value


def iter_log_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    if path.is_dir():
        files = [p for p in path.rglob("*") if p.is_file()]
        return sorted(files)
    raise FileNotFoundError(f"no such file or directory: {path}")


def read_entries(
    path: Path,
    pattern: str | None,
    level: str | None,
    tail: int | None,
) -> list[dict]:
    regex = re.compile(pattern) if pattern else None
    entries: list[dict] = []

    for file in iter_log_files(path):
        try:
            lines = file.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError as exc:
            entries.append({"file": str(file), "line_number": 0, "line": f"<unreadable: {exc}>"})
            continue

        for line_number, line in enumerate(lines, start=1):
            if level and level.upper() not in line.upper():
                continue
            if regex and not regex.search(line):
                continue
            entries.append({"file": str(file), "line_number": line_number, "line": line})

    if tail is not None:
        entries = entries[-tail:]

    return entries


def main() -> int:
    parser = argparse.ArgumentParser(description="Read and filter log entries.")
    parser.add_argument("--path", required=True, help="Path to a log file or a directory of log files.")
    parser.add_argument("--pattern", default=NONE_SENTINEL, help="Regex pattern to filter lines.")
    parser.add_argument("--level", default=NONE_SENTINEL, help="Log level substring to filter on, e.g. ERROR.")
    parser.add_argument("--tail", default=NONE_SENTINEL, help="Only return the last N matching entries.")
    args = parser.parse_args()

    pattern = resolve(args.pattern)
    level = resolve(args.level)
    tail_raw = resolve(args.tail)
    tail = int(tail_raw) if tail_raw is not None else None

    try:
        entries = read_entries(Path(args.path), pattern, level, tail)
    except (OSError, re.error) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1

    print(json.dumps({"count": len(entries), "entries": entries}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
