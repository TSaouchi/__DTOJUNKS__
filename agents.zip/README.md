# agents

An [OpenCode](https://opencode.ai) project with two narrowly-scoped agents, each
backed by Python tools. Business logic is Python; the `.ts` files under
`.opencode/tools/` are thin wrappers that shell out to the Python scripts and
return their output.

## Layout

```
agents/
├── opencode.json                  # project config
├── AGENTS.md                      # project rules, read automatically by OpenCode
├── .opencode/
│   ├── agents/
│   │   ├── log-agent.md           # Agent 1: log analysis + CSV reporting
│   │   └── db-agent.md            # Agent 2: database inspection + SQL analysis
│   └── tools/
│       ├── log_reader.py / .ts    # read + filter logs from a path
│       ├── report_writer.py / .ts # write rows to a CSV report at a path
│       └── db_query.py / .ts      # execute SQL, read-only by default
└── data/                          # default SQLite file lives here (git-ignore this)
```

## Requirements

- OpenCode installed and a provider configured (`opencode auth login` or `/connect`).
- `python3` on your `PATH` (both tools call it via `python3`, no extra pip packages
  needed — `log_reader`, `report_writer`, and the default SQLite backend only use
  the standard library).

## Running it

```sh
cd agents
opencode
```

Then either let OpenCode's default agent hand off automatically based on your
request, or invoke an agent directly:

```
@log-agent find every ERROR in /var/log/app and summarize what's failing
@log-agent read /var/log/app.log, filter for ERROR, and write a CSV report to ./out/errors.csv
@db-agent what tables exist in the database and what do they look like?
@db-agent how many rows are in the users table, and what does the schema look like?
```

## Agent 1 — log-agent

- `log_reader(path, pattern?, level?, tail?)` — reads a file or every file in a
  directory, optionally filtered by regex `pattern`, a `level` substring
  (e.g. `ERROR`), and/or limited to the last `tail` matches. Returns JSON.
- `report_writer(output_path, rows, columns?)` — writes `rows` (a list of JSON
  objects) to a CSV at `output_path`, creating parent directories as needed.
  Column order defaults to the union of keys seen across all rows.

Test either script directly, without OpenCode:

```sh
python3 .opencode/tools/log_reader.py --path ./app.log --pattern __NONE__ --level ERROR --tail __NONE__
python3 .opencode/tools/report_writer.py --output-path ./out/report.csv \
  --rows '[{"level":"ERROR","message":"boom"}]' --columns __NONE__
```

(`__NONE__` is the sentinel the `.ts` wrapper sends for an omitted optional flag —
see `AGENTS.md` for why.)

## Agent 2 — db-agent

- `db_query(query, params?, max_rows?, allow_write?)` — executes one SQL
  statement and returns `{columns, rows, row_count, truncated}` for
  SELECT-like statements, or `{message, rows_affected}` for writes.
- **Read-only by default.** INSERT/UPDATE/DELETE/DDL statements are rejected
  unless `allow_write: true` is passed. `PRAGMA` is always allowed since
  SQLite schema inspection depends on it.
- Ships with a zero-dependency **SQLite** backend. The database file path comes
  from the `AGENT_DB_PATH` env var, defaulting to `data/agent.db`.

Test directly:

```sh
export AGENT_DB_PATH=./data/agent.db
python3 .opencode/tools/db_query.py --query "SELECT name, type FROM sqlite_master WHERE type='table'" \
  --params __NONE__ --max-rows __NONE__ --allow-write false
```

### Swapping in Postgres or Oracle

Everything except `get_connection()` in `db_query.py` is backend-agnostic — the
read-only guard, row limiting, and JSON shaping all work through the standard
DB-API 2.0 cursor interface. To point it at a real database, replace that one
function, e.g.:

```python
# Oracle (pip install oracledb)
import oracledb
def get_connection():
    return oracledb.connect(os.environ["AGENT_DB_URL"])  # "user/pass@dsn"
```

```python
# Postgres (pip install psycopg2-binary)
import psycopg2
def get_connection():
    return psycopg2.connect(os.environ["AGENT_DB_URL"])
```

## Sandboxing

Both agents deny `edit`, `bash`, `webfetch`, and `websearch`, and each agent's
own tool is denied to the other via `permission` in its frontmatter — so
log-agent can never touch the database, and db-agent can never touch the
filesystem beyond what `db_query` does. See `.opencode/agents/*.md`.

## Extending

- More log formats: teach `log_reader.py` to parse structured (JSON) logs and
  return typed fields instead of raw lines.
- More export formats: add a sibling `report_writer_json.py` / `.ts` pair
  rather than overloading `report_writer` — keeps each tool single-purpose.
- Write guardrails on `db_query`: the keyword blocklist is intentionally
  simple; swap in `sqlglot` if you want real statement-type parsing instead of
  a first-token check.
