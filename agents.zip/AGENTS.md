# agents

An OpenCode project with two narrowly-scoped agents, each backed by Python tools.

## Agents

- **log-agent** — reads and filters log files, then writes findings out as a CSV report.
  Tools: `log_reader`, `report_writer`.
- **db-agent** — inspects a database and runs SQL for analysis.
  Tool: `db_query`.

## Conventions

- All business logic lives in Python (`.opencode/tools/*.py`). The matching `.ts` files
  are thin wrappers that shell out to the Python script via `Bun.$` and return its stdout.
- Every Python tool is a standalone CLI (`argparse`) that can be run and tested directly,
  independent of OpenCode — e.g. `python3 .opencode/tools/log_reader.py --path ./app.log ...`.
- Tools print one JSON object to stdout on success, and print a JSON error object to
  stderr with a non-zero exit code on failure. A non-zero exit makes `Bun.$` throw, which
  OpenCode surfaces to the model as a tool error.
- Optional CLI flags that aren't provided are passed through as the literal string
  `__NONE__` from the `.ts` wrapper, since `Bun.$` only interpolates single scalar
  arguments safely. Each Python script converts `__NONE__` back to `None`.
- Agents are deliberately sandboxed: `edit`, `bash`, `webfetch`, and `websearch` are
  denied in their permissions, and each agent's own tool is denied to the other. They can
  only act through the one or two tools assigned to them.
